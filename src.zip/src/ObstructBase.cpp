#include "ObstructBase.h"

//-----------------------------------------------------------------------------
// @brief  �R���X�g���N�^
//-----------------------------------------------------------------------------
ObstructBase::ObstructBase(int i)
{
	if (i % 2 == 0)
	{
		// �R�c���f���̓ǂݍ���
		modelHandle = MV1LoadModel("data/model/obstructFloat/obstructFloat.pmx");
		if (modelHandle < 0)
		{
			printfDx("ObstructFloat:�f�[�^�ǂݍ��݂Ɏ��s");
		}
		pos = VGet(0, 0, 0);
		rad = 0;
	}
	printfDx("ObstructBase!\n");
}

//-----------------------------------------------------------------------------
// @brief  �f�X�g���N�^
//-----------------------------------------------------------------------------
ObstructBase::~ObstructBase()
{
	printfDx("~ObstructBase!\n");
}

//-----------------------------------------------------------------------------
// @brief  3D���f���̕`��.
//-----------------------------------------------------------------------------
void ObstructBase::Draw()
{
	// �R�c���f���̕`��
	MV1DrawModel(modelHandle);
}