﻿//-----------------------------------------------------------------------------
// @brief  障害物：動かない.
// 2016 Takeru Yui All Rights Reserved.
//-----------------------------------------------------------------------------
#include "ObstructStatic.h"

//-----------------------------------------------------------------------------
// @brief  コンストラクタ.
//-----------------------------------------------------------------------------
ObstructStatic::ObstructStatic()
{
	// ３Ｄモデルの読み込み
	modelHandle = MV1LoadModel("data/model/obstructStatic/obstructStatic.pmd");
	if (modelHandle < 0)
	{
		printfDx("ObstructStatic:データ読み込みに失敗");
	}

	pos = VGet(0, 0, 0);
	printfDx("ObstructStatic!\n");
}

//-----------------------------------------------------------------------------
// @brief  デストラクタ.
//-----------------------------------------------------------------------------
ObstructStatic::~ObstructStatic()
{
	// モデルのアンロード.
	MV1DeleteModel(modelHandle);
	printfDx("~ObstructStatic!\n");
}

//-----------------------------------------------------------------------------
// @brief  更新.
//-----------------------------------------------------------------------------
void ObstructStatic::Update()
{
	// ３Dモデルのポジション設定
	MV1SetPosition(modelHandle, pos);
}
