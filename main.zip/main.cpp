#include <iostream>
#include <string>
#include <vector>
#include <list>
#include <map>
#include <string>
#include "minmax.h"

using namespace std;

void main() {
	map<char, string>mp;
	vector<char>vCh;
	string value;
	bool flag = false;
	char ch;
	char v[] = { '0','1','2','3','4','5','6','7','8','9' };
	mp[v[0]] = "�Z";
	mp[v[1]] = "��";
	mp[v[2]] = "��";
	mp[v[3]] = "�O";
	mp[v[4]] = "�l";
	mp[v[5]] = "��";
	mp[v[6]] = "�Z";
	mp[v[7]] = "��";
	mp[v[8]] = "��";
	mp[v[9]] = "��";
	
	cout << "�����̒l����͂��Ă�������:";
	cin >> value;

	for (int i = 0; i < (int)value.size(); i++)
	{
		ch = value[i];
		for (int j = 0; j < 10; j++)
		{
			if (ch == v[j])
			{
				vCh.push_back(v[j]);
				break;
			}
		}
		if ((value.size() - i - 1) % 3 == 0)
		{
			if (value[i + 1] != value.empty())
			{
				vCh.push_back(',');
			}
		}
	}

	for (int i = 0; i < vCh.size(); i++)
	{
		for (int j = 0; j < 10; j++)
		{
			if (vCh[i] == v[j])
			{
				flag = false;
			}
			else
			{
				flag = true;
				break;
			}
		}
		if (flag) break;
	}

	if (flag)
	{
		cout << "�����̒l����͂��Ă��������B";
	}
	else
	{
		for (int i = 0; i < vCh.size(); i++)
		{
			cout << mp[v[i]];
		}
	}
	getchar();
}
